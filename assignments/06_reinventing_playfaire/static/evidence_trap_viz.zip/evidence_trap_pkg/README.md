# The Evidence Trap

Visualizes how Wikipedia arbitration cases differ by how long they stay in the evidence-gathering phase.
Science and Geopolitics cases stay trapped gathering evidence long after Politics and Policy cases have ruled.

## Run

```
make serve
```

Open: http://localhost:8888/viz/evidence_trap.html

Requires Python 3 only — D3 v7 loads from CDN, no install needed.

## Contents

```
viz/evidence_trap.html   The visualization
data/processed/d3/       53 arbitration case JSON files (2004–2025)
static/                  PNG · SVG · PDF exports
```

## Data

Each JSON file in `data/processed/d3/` represents one Wikipedia arbitration case.
Events have `timestamp`, `page_type` (article/evidence/workshop/proposed_decision/outcome/main), and `actor` fields.
